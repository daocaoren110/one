#include "usart.h"

USART_InitTypeDef		USART1_Struct;
GPIO_InitTypeDef		USART1_GPIO_Struct;
NVIC_InitTypeDef 		USART1_NVIC_Struct;
//USART1 ��ʼ��
//PB9  TX
//PB10 RX
void USART_Configuration ( void )
{
	RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOA, ENABLE );	
	RCC_APB2PeriphClockCmd( RCC_APB2Periph_USART1, ENABLE );
	RCC_APB2PeriphClockCmd(  RCC_APB2Periph_AFIO, ENABLE);	
	
	
	USART1_GPIO_Struct.GPIO_Pin 			= GPIO_Pin_9;
	USART1_GPIO_Struct.GPIO_Mode		= GPIO_Mode_AF_PP;
	USART1_GPIO_Struct.GPIO_Speed 	= GPIO_Speed_50MHz;
	GPIO_Init( GPIOA, &USART1_GPIO_Struct );
	USART1_GPIO_Struct.GPIO_Pin 			= GPIO_Pin_10;
	USART1_GPIO_Struct.GPIO_Mode		= GPIO_Mode_IN_FLOATING;
	GPIO_Init( GPIOA, &USART1_GPIO_Struct );
	
	USART1_Struct.USART_BaudRate = 115200;
	USART1_Struct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART1_Struct.USART_Mode = USART_Mode_Tx|USART_Mode_Rx;
	USART1_Struct.USART_Parity = USART_Parity_No;
	USART1_Struct.USART_StopBits = USART_StopBits_1;
	USART1_Struct.USART_WordLength = USART_WordLength_8b;
	USART_Init( USART1,  &USART1_Struct );
	
	USART_Cmd( USART1, ENABLE );
	
	USART1_NVIC_Struct.NVIC_IRQChannel = USART1_IRQn;
	USART1_NVIC_Struct.NVIC_IRQChannelPreemptionPriority = 0;//��ռ���ȼ�
	USART1_NVIC_Struct.NVIC_IRQChannelSubPriority = 0;//��Ӧ���ȼ�
	USART1_NVIC_Struct.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init( &USART1_NVIC_Struct );
	
	USART_ITConfig( USART1, USART_IT_RXNE, ENABLE );
	USART_ClearFlag(USART1, USART_FLAG_TC|USART_FLAG_RXNE);
}

//USART1��ӳ�䲢��ʼ��
//PB6 TX
//PB7 RX
void USART1_Remap_Configuration (  void ) 
{
	
	RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOB, ENABLE );
	RCC_APB2PeriphClockCmd( RCC_APB2Periph_USART1, ENABLE );
	RCC_APB2PeriphClockCmd(  RCC_APB2Periph_AFIO, ENABLE);	
	GPIO_PinRemapConfig( GPIO_Remap_USART1, ENABLE );//��ӳ��
	
	USART1_GPIO_Struct.GPIO_Pin 			= GPIO_Pin_6;//TX
	USART1_GPIO_Struct.GPIO_Mode		= GPIO_Mode_AF_PP;
	USART1_GPIO_Struct.GPIO_Speed 	= GPIO_Speed_50MHz;
	GPIO_Init( GPIOB, &USART1_GPIO_Struct );	
	USART1_GPIO_Struct.GPIO_Pin 			= GPIO_Pin_7;//RX
	USART1_GPIO_Struct.GPIO_Mode		= GPIO_Mode_IN_FLOATING;
	GPIO_Init( GPIOB, &USART1_GPIO_Struct );	
	
	USART1_Struct.USART_BaudRate = 115200;
	USART1_Struct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART1_Struct.USART_Mode = USART_Mode_Tx|USART_Mode_Rx;
	USART1_Struct.USART_Parity = USART_Parity_No;
	USART1_Struct.USART_StopBits = USART_StopBits_1;
	USART1_Struct.USART_WordLength = USART_WordLength_8b;
	USART_Init( USART1,  &USART1_Struct );	
	USART_Cmd( USART1, ENABLE );
}


void USART_Send_Byte ( u8* ch )
{
	while( *ch != '\0' )
	{
		USART_SendData( USART1,*(ch++) );
		while(USART_GetFlagStatus( USART1, USART_FLAG_TC )==RESET);
	}
}

int fputc ( int ch, FILE* f )
{
	USART_SendData( USART1, ch );
	while( USART_GetFlagStatus( USART1, USART_FLAG_TXE ) == RESET );
	return ( ch );
}

void USART1_IRQHandler ( void )
{
	u16 send_ch;
	
	if( USART_GetFlagStatus( USART1, USART_FLAG_RXNE ) == SET )
	{
		send_ch = USART_ReceiveData( USART1 );
		USART_SendData( USART1, send_ch );
	}
}
