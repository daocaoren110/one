#ifndef __USART_H_
#define __USART_H_

#include "stm32f10x.h"
#include "stdio.h"

void USART_Configuration ( void );
void USART1_Remap_Configuration (  void );
void USART_Send_Byte ( u8* ch );
int fputc ( int ch, FILE* f );

#endif


