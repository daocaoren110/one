#ifndef __ADC_H_
#define __ADC_H_

#include "stm32f10x.h"

void ADC1_DMAConfiguration ( u32 MemoryBaseAddr, u16 BufferSize );
void ADC1_INxConfigurtion  ( void );
void ADC1_ScanInit ( void );
void ADC1_ConversionTransferStart ( void );
void LCD_DisplayDianYa ( void );

#endif

