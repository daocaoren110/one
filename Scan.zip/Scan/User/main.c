/*	�ж�������  	NVIC_PriorityGroup_1
 *	Channel				PreemptionPriority	SubPriority
 *	USART1_IRQn						0								0
 *	DMA1_Channel1_IRQn		0								1
 *	TIM3_IRQn							0								3
*/


#include "stm32f10x.h"
#include "delay.h"
#include "usart.h"
#include "LCD_Driver.h"
#include "LCD_DrawImage.h"
#include "adc.h"

int main ( void )
{


	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
	RCC_APB2PeriphClockCmd( RCC_APB2Periph_AFIO, ENABLE );
	
	Delay_Init();
	USART_Configuration();
	
	LCD_Init();
	ADC1_ScanInit();
	
	ADC1_ConversionTransferStart();

	while(1)
	{

	}//end while(1)
	
}//end main

